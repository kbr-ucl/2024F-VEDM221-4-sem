﻿global using System.Text.Json;
global using Dapr;
global using Dapr.Client;
global using Microsoft.AspNetCore.Mvc;
global using sample.microservice.dto.shipping;
global using sample.microservice.common;
global using sample.microservice.state.shipping;
