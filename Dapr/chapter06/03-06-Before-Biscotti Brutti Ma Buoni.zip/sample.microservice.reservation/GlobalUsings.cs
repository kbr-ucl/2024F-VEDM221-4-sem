﻿global using System.Text.Json;
global using Dapr;
global using Dapr.Client;
global using Microsoft.AspNetCore.Mvc;
global using sample.microservice.dto.order;
global using sample.microservice.dto.reservation;
global using sample.microservice.dto.customization;
global using sample.microservice.state.reservation;
